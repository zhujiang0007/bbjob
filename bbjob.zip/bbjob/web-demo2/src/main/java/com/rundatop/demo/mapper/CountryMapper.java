package com.rundatop.demo.mapper;

import com.rundatop.demo.model.Country;
import tk.mybatis.mapper.common.Mapper;

public interface CountryMapper extends Mapper<Country> {
}