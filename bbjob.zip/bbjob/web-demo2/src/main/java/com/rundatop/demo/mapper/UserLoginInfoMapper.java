package com.rundatop.demo.mapper;

import com.rundatop.demo.model.UserLoginInfo;
import tk.mybatis.mapper.common.Mapper;

public interface UserLoginInfoMapper extends Mapper<UserLoginInfo> {
}