package com.rundatop.demo.mapper;

import com.rundatop.demo.model.UserInfo;
import tk.mybatis.mapper.common.Mapper;

public interface UserInfoMapper extends Mapper<UserInfo> {
}