package com.rundatop.core.dao;

public interface RsRow {
	public Object getValue(String key);
}
