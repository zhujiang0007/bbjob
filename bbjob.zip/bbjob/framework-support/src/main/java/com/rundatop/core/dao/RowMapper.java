package com.rundatop.core.dao;


public interface RowMapper {
	public Object mapRow(RsRow rs, int i);
}
