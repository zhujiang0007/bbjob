package com.rundatop.core.dao;

public interface PreparedStatement {
	public void setValue(int i, Object v);
}
