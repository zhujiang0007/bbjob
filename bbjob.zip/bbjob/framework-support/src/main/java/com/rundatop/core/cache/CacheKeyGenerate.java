package com.rundatop.core.cache;

public interface CacheKeyGenerate {
	public String createCacheKey();
}
